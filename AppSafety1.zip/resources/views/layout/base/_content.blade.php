{{-- Content --}}
@if (config('layout.content.extended'))
    @yield('content')
@else

    @yield('content')

@endif
